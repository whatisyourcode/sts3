insert into item(name, price, stockquantity) values ('연필', 300, 100),
 ('공책', 700, 50)