package com.study.springboot.jdbc;

import lombok.Data;

@Data
public class MyUserDTO {

    private String id;
    private String name;
}
