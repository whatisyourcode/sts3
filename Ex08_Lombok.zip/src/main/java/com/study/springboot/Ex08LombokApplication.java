package com.study.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex08LombokApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex08LombokApplication.class, args);
	}

}
